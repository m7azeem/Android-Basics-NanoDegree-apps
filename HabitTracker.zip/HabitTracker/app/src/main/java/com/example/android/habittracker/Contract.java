package com.example.android.habittracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Contract {

    public Contract(Context ourContext) {
        this.ourContext = ourContext;
    }

    private static final String DATABASE_NAME = "myActivities";
    private static final int DATABASE_VERSION = 1;

    private DBHelper ourHelper;
    private Context ourContext;
    private SQLiteDatabase ourDatabase;

    public static class funTable{
        private static final String FUN_TABLE = "fun";

        public static final String FUN_ROWID = "id";
        public static final String FUN_ACTIVITY = "funActivity";
        public static final String FUN_MINUTES = "funMinutes";
    }

    public static class workTable{
        private static final String WORK_TABLE = "work";

        public static final String WORK_ROWID = "id";
        public static final String WORK_ACTIVITY = "workActivity";
        public static final String WORK_MINUTES = "workMinutes";
    }

    public SQLiteDatabase open(){
        ourHelper = new DBHelper(ourContext);
        ourDatabase = ourHelper.getWritableDatabase();
        return ourDatabase;
    }
    public void close(){
        ourHelper.close();
    }

    public class DBHelper extends SQLiteOpenHelper {

        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            ourDatabase.execSQL("CREATE TABLE "+funTable.FUN_TABLE+" {"+

                    funTable.FUN_ROWID+ " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                    funTable.FUN_ACTIVITY+ " TEXT NOT NULL " +
                    funTable.FUN_MINUTES+ " INTEGER NOT NULL, "+ " )"
            );

            ourDatabase.execSQL("CREATE TABLE "+workTable.WORK_TABLE+" {"+

                    workTable.WORK_ROWID+ " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                    workTable.WORK_ACTIVITY+ " TEXT NOT NULL " +
                    workTable.WORK_MINUTES+ " INTEGER NOT NULL, "+ " )"
            );

        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
            ourDatabase.execSQL("DROP TABLE IF EXISTS " + funTable.FUN_TABLE);
            ourDatabase.execSQL("DROP TABLE IF EXISTS " + workTable.WORK_TABLE);
            onCreate(ourDatabase);
        }

        public void deleteDatabase(){
            ourContext.deleteDatabase(DATABASE_NAME);
        }

    }


    //enters data into the table
    public long insertFUN() {
        ContentValues cv = new ContentValues();
        cv.put(funTable.FUN_ROWID, 1);
        cv.put(funTable.FUN_ACTIVITY, "tennis");
        cv.put(funTable.FUN_MINUTES, 40);
        return ourDatabase.insert(funTable.FUN_TABLE, null, cv);
    }

    //get data from db
    public Cursor read() {
        String[] columns = new String[]{
                funTable.FUN_ROWID,
                funTable.FUN_ACTIVITY,
                funTable.FUN_MINUTES
        };
        // How you want the results sorted in the resulting Cursor
        String sortOrder = funTable.FUN_ACTIVITY;

        Cursor c = ourDatabase.query(
                funTable.FUN_TABLE,     // The table to query
                columns,                // The columns to return
                null,                   // The columns for the WHERE clause
                null,                   // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null                    // The sort order
        );

        return c;
    }

    public long delete(){
        return ourDatabase.delete(funTable.FUN_TABLE, null, null);
    }

    public void update(){
        // New value for one column
        ContentValues values = new ContentValues();
        values.put(funTable.FUN_ACTIVITY, "chill");

        // Which row to update, based on the ID
        String selection = funTable.FUN_ROWID + 1;
        String[] selectionArgs = { String.valueOf(funTable.FUN_ROWID) };

        int count = ourDatabase.update(
                funTable.FUN_TABLE,
                values,
                selection,
                selectionArgs);
    }

}
