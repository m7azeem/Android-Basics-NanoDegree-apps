package com.example.android.dubaiattractions;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class OutdoorsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location("Zabeel Park", "Level Mint"));
        locations.add(new Location("Safa Park", "Famous"));
        locations.add(new Location("Creek Park", "Techy"));
        locations.add(new Location("Mumzar", "A classic"));

        LocationAdapter adapter = new LocationAdapter(this, locations, R.color.category_numbers);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
