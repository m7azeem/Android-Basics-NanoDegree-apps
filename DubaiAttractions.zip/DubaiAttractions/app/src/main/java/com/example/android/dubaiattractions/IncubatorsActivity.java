package com.example.android.dubaiattractions;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class IncubatorsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location("In5", "Awesome"));
        locations.add(new Location("Turn8", "A Must Visit"));
        locations.add(new Location("AstroLabs", "Brand New"));
        locations.add(new Location("Silicon Oasis", "its Mint"));

        LocationAdapter adapter = new LocationAdapter(this, locations, R.color.category_numbers);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
