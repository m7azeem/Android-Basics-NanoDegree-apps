package com.example.android.dubaiattractions;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        TextView incubators = (TextView) findViewById(R.id.incubators);

        incubators.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent incubatorsIntent = new Intent(MainActivity.this, IncubatorsActivity.class);

                startActivity(incubatorsIntent);
            }
        });


        TextView sites = (TextView) findViewById(R.id.sites);

        sites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sitesIntent = new Intent(MainActivity.this, SitesActivity.class);

                startActivity(sitesIntent);
            }
        });


        TextView outdoors= (TextView) findViewById(R.id.outdoors);

        outdoors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent outdoorsIntent = new Intent(MainActivity.this, OutdoorsActivity.class);

                startActivity(outdoorsIntent);
            }
        });


        TextView malls = (TextView) findViewById(R.id.malls);

        malls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mallsIntent = new Intent(MainActivity.this, MallsActivity.class);

                startActivity(mallsIntent);
            }
        });
    }
}
