package com.example.android.dubaiattractions;

public class Location {

    private String name;
    private String review;
    private int imageResourceId = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;

    public Location(String name, String review) {
        this.name=name;
        this.review=review;
    }

    public Location(String name, String review, int imageResourceId) {
        this.name=name;
        this.review=review;
        this.imageResourceId = imageResourceId;
    }

    public String getName() {
        return name;
    }

    public String getReview() {
        return review;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public boolean hasImage() {
        return imageResourceId != NO_IMAGE_PROVIDED;
    }
}
