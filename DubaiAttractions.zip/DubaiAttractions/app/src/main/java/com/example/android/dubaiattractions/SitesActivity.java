package com.example.android.dubaiattractions;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class SitesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_list);

        ArrayList<Location> locations = new ArrayList<Location>();
        locations.add(new Location("Burj Khalifa", "it's Tall", R.drawable.burjkhalifa));
        locations.add(new Location("Burj al Arab", "The Icon", R.drawable.burjalarab));
        locations.add(new Location("The Palm", "wow", R.drawable.palm));
        locations.add(new Location("Heriot Watt", "Mint", R.drawable.hw));

        LocationAdapter adapter = new LocationAdapter(this, locations, R.color.category_numbers);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
