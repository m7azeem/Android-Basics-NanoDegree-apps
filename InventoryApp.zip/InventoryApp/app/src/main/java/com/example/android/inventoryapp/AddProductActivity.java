package com.example.android.inventoryapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddProductActivity extends AppCompatActivity {

    public static final int CAMERA_REQUEST = 10;
    Product  p;
    Uri pictureUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        final Button save = (Button) findViewById(R.id.save_button_add_product);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p = new Product();
                EditText nameET = (EditText) findViewById(R.id.name_add_product);
                if( nameET.getText().toString()==null){
                    Toast.makeText(AddProductActivity.this, "Check inputs!", Toast.LENGTH_LONG).show();
                    return;
                } else{
                    p.setProductName(nameET.getText().toString());
                }

                EditText priceET = (EditText) findViewById(R.id.price_add_product);
                if(  priceET.getText().length()<1){
                    Toast.makeText(AddProductActivity.this, "Check inputs!", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    p.setPrice(Integer.parseInt((priceET.getText().toString())));
                }

                EditText quantityET = (EditText) findViewById(R.id.quantity_add_product);
                if( quantityET.getText().length()<1){
                    Toast.makeText(AddProductActivity.this, "Check inputs!", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    p.setQuantity(Integer.parseInt((quantityET.getText().toString())));
                }

                if( pictureUri==null){
                    Toast.makeText(AddProductActivity.this, "Check inputs!", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    p.setImageUri(pictureUri);
                }
                MainActivity.arrayList.add(p);
                Intent saveAndGoBack = new Intent(AddProductActivity.this, MainActivity.class);
                saveAndGoBack.putExtra("updateStorage", true);
                startActivity(saveAndGoBack);
            }
        });

        final Button addImage = (Button) findViewById(R.id.add_product_image);

        addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File pictureDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                String pictureName = getPictureName();
                File imageFile = new File(pictureDirectory,pictureName);
                pictureUri = Uri.fromFile(imageFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,pictureUri);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        });
    }

    private String getPictureName() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timeStamp = sdf.format(new Date());
        return "ProductImage" + timeStamp + ".jpg";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==CAMERA_REQUEST && resultCode==RESULT_OK){
            Bitmap bitmap = getBitmapFromUri(pictureUri);
            Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap,30,30,false);
            ImageView iv = (ImageView) findViewById(R.id.added_image);
            iv.setImageBitmap(resizedBitmap);
        }
    }

    private Bitmap getBitmapFromUri(Uri uri){
        ParcelFileDescriptor pfd = null;
        try {
            pfd = getContentResolver().openFileDescriptor(uri, "r");
            FileDescriptor fd = pfd.getFileDescriptor();
            Bitmap bitmap = BitmapFactory.decodeFileDescriptor(fd);
            return bitmap;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
