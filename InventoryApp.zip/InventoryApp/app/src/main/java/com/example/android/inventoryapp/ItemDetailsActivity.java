package com.example.android.inventoryapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;

public class ItemDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);

        Bundle checker = getIntent().getExtras();
        if(checker!=null){
            final int position = checker.getInt("itemPosition");
            final Product p = MainActivity.arrayList.get(position);
            TextView nameTv = (TextView) findViewById(R.id.name_details);
            nameTv.setText(p.getProductName());

            TextView salesTv = (TextView) findViewById(R.id.sales_details);
            salesTv.setText(Integer.toString(p.getSalesAmount()));

            TextView priceTv = (TextView) findViewById(R.id.price_details);
            priceTv.setText(Integer.toString(p.getPrice()));

            TextView quantityTv = (TextView) findViewById(R.id.quantity_details);
            quantityTv.setText(Integer.toString(p.getQuantity()));

            ImageView image = (ImageView) findViewById(R.id.image_details);
            if(p.getImageUri()!=null){
                Bitmap bitmap = getBitmapFromUri(p.getImageUri());
                image.setImageBitmap(bitmap);
            }
            Button emailSupplier = (Button) findViewById(R.id.email_supplier);
            emailSupplier.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    Intent emailIntent = new Intent(Intent.ACTION_SEND);
                    emailIntent.setData(Uri.parse("mailto:"));
                    emailIntent.setType("text/plain");
                    String[] TO ={"mysupplier@gmail.com"};
                    emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                    startActivity(emailIntent);
                }
            });

            Button deleteItem = (Button) findViewById(R.id.delete_item);
            deleteItem.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    MainActivity.arrayList.remove(position);
                    updateDB();
                }
            });

            Button quantityMinus = (Button) findViewById(R.id.quantity_minus);
            quantityMinus.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    MainActivity.arrayList.get(position).setQuantity(MainActivity.arrayList.get(position).getQuantity()-1);
                    TextView quantityTv = (TextView) findViewById(R.id.quantity_details);
                    quantityTv.setText(Integer.toString(MainActivity.arrayList.get(position).getQuantity()));
                }
            });

            Button quantityPlus = (Button) findViewById(R.id.quantity_plus);
            quantityPlus.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    MainActivity.arrayList.get(position).setQuantity(MainActivity.arrayList.get(position).getQuantity()+1);
                    TextView quantityTv = (TextView) findViewById(R.id.quantity_details);
                    quantityTv.setText(Integer.toString(MainActivity.arrayList.get(position).getQuantity()));
                }
            });

            Button saveDetails = (Button) findViewById(R.id.save_details);
            saveDetails.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    updateDB();
                }
            });
        }
    }

    private Bitmap getBitmapFromUri(Uri uri){
        ParcelFileDescriptor parcelFileDescriptor = null;
        try {
            parcelFileDescriptor = getContentResolver().openFileDescriptor(uri, "r");
            FileDescriptor fd = parcelFileDescriptor.getFileDescriptor();
            Bitmap bitmap = BitmapFactory.decodeFileDescriptor(fd);
            return bitmap;
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        }
        return null;
    }
    private void updateDB(){
        Intent updateDBIntent = new Intent(ItemDetailsActivity.this,MainActivity.class);
        updateDBIntent.putExtra("updateStorage", true);
        startActivity(updateDBIntent);
    }
}
