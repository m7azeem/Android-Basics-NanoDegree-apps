package com.example.android.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Product> arrayList= new ArrayList<Product>();
    public static ProductsAdapter adapter;
    static int timesLoaded=0;
    MyDBHandler dbHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHandler = new MyDBHandler(this, null,null,1);//making myHandler again and again can overwrite the db???
        if(timesLoaded==0){
            timesLoaded++;
            arrayList=dbHandler.databaseToList();
        }
        Bundle checker = getIntent().getExtras();
        if(checker!=null){
            if(checker.getBoolean("updateStorage")==true){
                dbHandler.deleteAll();
                for (int i=0; i<arrayList.size();i++){
                    dbHandler.addProduct(arrayList.get(i));
                }
                arrayList=dbHandler.databaseToList();
            }
        }
        if(arrayList.size()>0){
            TextView msgTv = (TextView) findViewById(R.id.msg_main);
            msgTv.setText("");
        }
        adapter = new ProductsAdapter(MainActivity.this, arrayList);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent detailsIntent = new Intent(MainActivity.this, ItemDetailsActivity.class);
                detailsIntent.putExtra("itemPosition",position);
                startActivity(detailsIntent);
            }
        });

        Button bu = (Button) findViewById(R.id.add_product_button);
        bu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addProduct = new Intent(MainActivity.this, AddProductActivity.class);
                startActivity(addProduct);
            }
        });

        Button saveSales = (Button) findViewById(R.id.save_sales_main);
        saveSales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbHandler.deleteAll();
                for (int i=0; i<arrayList.size();i++){
                    dbHandler.addProduct(arrayList.get(i));
                }
                arrayList=dbHandler.databaseToList();
                 TextView saveTv = (TextView) findViewById(R.id.msg_main);
                    saveTv.setText("Saved sales and other changes");
            }
        });

    }
}
