package com.example.android.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

import java.util.ArrayList;

public class MyDBHandler extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    public static int DATABASE_VERSION = 4;
    private static final String PRODUCT_TABLE = "product_Table";
    public static final String ROW_ID = "_id";
    public static final String NAME = "name";
    public static final String SUPPLIER_EMAIL = "supplierEmail";
    public static final String QUANTITY = "quantity";
    public static final String PRICE = "price";
    public static final String SALES_AMOUNT = "salesAmount";
    public static final String IMAGE_URI_STRING = "uriString";

    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE "+ PRODUCT_TABLE+ "("+
                ROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NAME + " TEXT, " +
                SUPPLIER_EMAIL +  " TEXT, " +
                QUANTITY +  " INTEGER, " +
                PRICE +   " INTEGER, " +
                SALES_AMOUNT +   " INTEGER, " +
                IMAGE_URI_STRING +   " TEXT " +
                ");";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + PRODUCT_TABLE);
        onCreate(db);
    }

    public void deleteAll(){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("delete from "+ PRODUCT_TABLE);
        db.close();

    }
    public void addProduct(Product product){
        ContentValues values = new ContentValues();
        values.put(NAME,product.getProductName());
        values.put(QUANTITY, product.getQuantity());
        values.put(PRICE, product.getPrice());
        values.put(SALES_AMOUNT, product.getSalesAmount());
        String uriString = product.getImageUri().toString();
        values.put(IMAGE_URI_STRING, uriString);
        SQLiteDatabase db = getWritableDatabase();
        db.insert(PRODUCT_TABLE, null, values);
        db.close();
    }
    public ArrayList<Product> databaseToList(){
        SQLiteDatabase db =  getWritableDatabase();
        String query = "SELECT * FROM " + PRODUCT_TABLE + " WHERE 1";
        Cursor c = db.rawQuery(query, null);
        c.moveToFirst();
        ArrayList<Product> pList = new ArrayList<Product>();
        while (!c.isAfterLast()) {
            Product p = new Product();
            if (c.getString(c.getColumnIndex("name")) != null) {
                p.setProductName(c.getString(c.getColumnIndex("name")));
            }
            if (!(c.getInt(c.getColumnIndex(QUANTITY)) < 0)) {
                p.setQuantity(c.getInt((c.getColumnIndex(QUANTITY))));
            }
            if (!(c.getInt(c.getColumnIndex(PRICE)) < 0)) {
                p.setPrice(c.getInt((c.getColumnIndex(PRICE))));
            }
            if (!(c.getInt(c.getColumnIndex(SALES_AMOUNT)) < 0)) {
                p.setSalesAmount(c.getInt((c.getColumnIndex(SALES_AMOUNT))));
            }
            if (c.getString(c.getColumnIndex(IMAGE_URI_STRING)) != null) {
                p.setImageUri(Uri.parse(c.getString(c.getColumnIndex(IMAGE_URI_STRING))));
            }
            pList.add(p);
            c.moveToNext();
        }

        db.close();
        return pList;
    }
}

