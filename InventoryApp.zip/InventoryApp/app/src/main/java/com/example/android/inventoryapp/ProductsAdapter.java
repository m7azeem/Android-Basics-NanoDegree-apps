package com.example.android.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ProductsAdapter extends ArrayAdapter<Product>{

    public ProductsAdapter(Context context, ArrayList<Product> arrayList){
        super(context,0, arrayList);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        View listItemView = convertView;
        if (listItemView==null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);

            Button addSale = (Button) listItemView.findViewById(R.id.record_sale_button_list_item);
            addSale.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Product p = MainActivity.arrayList.get(position);

                    if(MainActivity.arrayList.get(position).getQuantity()!=0){
                        MainActivity.arrayList.get(position).setSalesAmount(MainActivity.arrayList.get(position).getSalesAmount()+1);
                        MainActivity.arrayList.get(position).setQuantity(MainActivity.arrayList.get(position).getQuantity()-1);
                        MainActivity.adapter.notifyDataSetChanged();
                    }
                }
            });
        }

        Product currentProduct = getItem(position);

        TextView name = (TextView) listItemView.findViewById(R.id.name_list_item);
        name.setText(currentProduct.getProductName());

        TextView price = (TextView) listItemView.findViewById(R.id.price_list_item);
        price.setText(Integer.toString(currentProduct.getPrice()));

        TextView quantity= (TextView) listItemView.findViewById(R.id.quantity_list_item);
        quantity.setText(Integer.toString(currentProduct.getQuantity()));

        TextView sales= (TextView) listItemView.findViewById(R.id.sales_amount_list_item);
        sales.setText(Integer.toString(currentProduct.getSalesAmount()));

        return listItemView;
    }
}
