package com.example.android.booksearch;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Book> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            TextView infoMsg = (TextView) findViewById(R.id.output);
            infoMsg.setText("Please enter the search keywords and click Search");

        //useWebService(new View( this));


        /*Button bu = (Button) findViewById(R.id.button);

        bu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    useWebService();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                //Intent buIntent = new Intent(MainActivity.this, IncubatorsActivity.class);
                //startActivity(incubatorsIntent);
            }
        });*/
    }


    public void useWebService(View view) {


        Log.d("mylogs","webService1");
        Thread thread = new Thread(new Runnable() {
            //Log.d("mylogs","webService2");
            @Override
            public void run() {
                Log.d("mylogs","webService3");
                try {
                    WebService wb = new WebService();
                    EditText input = (EditText) findViewById(R.id.input);
                    String in = input.getText().toString();
                    in = URLEncoder.encode(in, "UTF-8");

                    String out = wb.doInBackground(in);
                    Log.d("mylogs","webService4");
                    Log.d("mylogs",out);
                    /*if (out == "Service not working. Please retry later.") {
                        Log.d("mylogs","webService5");
                        TextView tv = (TextView) findViewById(R.id.output);
                        tv.setText(out);
                        Log.d("mylogs","webService6");
                    } else {*/
                        Log.d("mylogs","webService7");
                        Parser parser = new Parser();
                    Log.d("mylogs","webService7.1");
                        arrayList = parser.parse(out);

                    Log.d("mylogs","the size is "+ Integer.toString(arrayList.size()) + "full stop.");
                    Log.d("mylogs","webService7.2");
                        //Parser parser = new Parser();
                        //arrayList = parser.parse(out);
                        //TextView tv = (TextView) findViewById(R.id.output);
                    /*Intent buIntent = new Intent(MainActivity.this, DisplayListActivity.class);
                    startActivity(buIntent);*/

                    //}
                } catch (Exception e) {
                    e.printStackTrace();
                    TextView tv = (TextView) findViewById(R.id.output);
                    tv.setText("error");
                    Log.d("mylogs","webService9");
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.d("mylogs","webService10");
        }
        TextView infoMsg = (TextView) findViewById(R.id.output);
        if(arrayList.size()==0){
            infoMsg.setText("No results found. Please enter the search keywords and click Search");
        } else {
            infoMsg.setText("");
            BooksAdapter adapter = new BooksAdapter(this,arrayList,R.color.colorPrimaryDark);
            ListView listView = (ListView) findViewById(R.id.list);
            listView.setAdapter(adapter);
        }

        Log.d("mylogs","webService7.3");
        String a = Integer.toString(arrayList.size());
        Log.d("mylogs","the size is "+ a + "full stop.");
        Log.d("mylogs","webService8");
    }

    public void testmethod(View view){
        //somework
        TextView tv = (TextView) findViewById(R.id.output);
        tv.setText("full stop.");
        //useWebService();
        //tv.setText("huiachoiacoajocj");
    }

}
