package com.example.android.guardiannews;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Parser {

    public ArrayList<Article> articles = new ArrayList<Article>();

    public ArrayList<Article> parse(String JsonData1){
        try {
            JSONObject jObject = new JSONObject(JsonData1);
            JSONObject jResponse = jObject.getJSONObject("response");
            JSONArray jArray = jResponse.getJSONArray("results");
            for (int i = 0; i < jArray.length(); i++) {
                JSONObject jArticle = jArray.getJSONObject(i);
                //Parent Object of JsonArray
                String sectionId = jArticle.getString("sectionId");
                String webTitle = jArticle.getString("webTitle");
                String webPublicationDate = jArticle.getString("webPublicationDate");
                String webUrl = jArticle.getString("webUrl");
                //adding to arraylist
                articles.add(new Article(sectionId,webTitle,webPublicationDate,webUrl));
            }

        } catch (JSONException e) {

            e.printStackTrace();
        }

        return articles;
    }
}
