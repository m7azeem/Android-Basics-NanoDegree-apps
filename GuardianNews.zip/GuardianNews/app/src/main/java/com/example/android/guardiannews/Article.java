package com.example.android.guardiannews;

/**
 * Created by Muhammad Azeem on 26/06/2016.
 */
public class Article {
    String sectionId="startValue";
    String webTitle="startValue";
    String webPublicationDate="startValue";
    String webUrl="startValue";

    public Article(String sectionId, String webTitle, String webPublicationDate, String webUrl) {
        this.sectionId = sectionId;
        this.webTitle = webTitle;
        this.webPublicationDate = "\n Date: "+webPublicationDate;
        this.webUrl = webUrl;
    }

    public String getSectionId() {
        return sectionId;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public void setWebTitle(String webTitle) {
        this.webTitle = webTitle;
    }

    public String getWebPublicationDate() {
        return webPublicationDate;
    }

    public void setWebPublicationDate(String webPublicationDate) {
        this.webPublicationDate = webPublicationDate;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }
}
