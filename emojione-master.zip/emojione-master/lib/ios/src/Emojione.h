//
//  Emojione.h
//
//  Created by Alessandro Calzavara on 16/12/14.
//  Copyright (c) 2014 Spreaker, Inc.
//

#import <Foundation/Foundation.h>

@interface Emojione : NSObject

+ (NSString *)shortnameToUnicode:(NSString *)string;

@end