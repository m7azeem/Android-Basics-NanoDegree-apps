package com.example.android.freeweeklytrendingsongs;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SongDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_details);

        //Find the View that shows the numbers category
        TextView trend= (TextView) findViewById(R.id.trend);
        //Set a clicklistener on that View
        trend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(SongDetails.this, MainActivity.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });
    }
}
