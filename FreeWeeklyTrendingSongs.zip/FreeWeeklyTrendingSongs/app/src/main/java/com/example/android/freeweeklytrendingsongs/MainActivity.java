package com.example.android.freeweeklytrendingsongs;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Find the View that shows the numbers category
        TextView angel = (TextView) findViewById(R.id.angel);
        //Set a clicklistener on that View
        angel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(MainActivity.this, SongDetails.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });

        //Find the View that shows the numbers category
        TextView sugar = (TextView) findViewById(R.id.sugar);
        //Set a clicklistener on that View
        sugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(MainActivity.this, SongDetails.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });

        //Find the View that shows the numbers category
        TextView fight = (TextView) findViewById(R.id.fight);
        //Set a clicklistener on that View
        fight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(MainActivity.this, SongDetails.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });

        //Find the View that shows the numbers category
        TextView bonus = (TextView) findViewById(R.id.bonus);
        //Set a clicklistener on that View
        bonus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(MainActivity.this, SongDetails.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });

        //Find the View that shows the numbers category
        TextView happy = (TextView) findViewById(R.id.happy);
        //Set a clicklistener on that View
        happy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(MainActivity.this, SongDetails.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });

        //Find the View that shows the numbers category
        TextView lean = (TextView) findViewById(R.id.lean);
        //Set a clicklistener on that View
        lean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create a new intent to open the {@link NumbersActivity}
                Intent numbersIntent = new Intent(MainActivity.this, SongDetails.class);
                //start the new activity
                startActivity(numbersIntent);
            }
        });
    }
}
